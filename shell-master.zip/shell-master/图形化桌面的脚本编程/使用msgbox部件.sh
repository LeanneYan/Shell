#!/bin/bash

dialog --title text --msgbox "This is a test" 10 20
