#!/bin/bash
# another example of how not to use the for command

for test in Newada "New Hampshire"
do
	echo "Now going to $test"
done
