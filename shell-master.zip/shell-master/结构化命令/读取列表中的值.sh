#!/bin/bash

# basic for command
for test in Alabama Alaska Arizona
do
	echo The next state is $test
done
