#!/bin/bash
#testing variables

days=10
guest="Katie"
echo "$guest logged in $days days age"
guest="Katie2"
days=5
echo "$guest logged in $days days age"
